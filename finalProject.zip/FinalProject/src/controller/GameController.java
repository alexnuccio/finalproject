package controller;
/**
 * The controller
 * @author emyre
 *
 */
public class GameController {
	/** 
	 * 	This is the constructor
	 */
	public GameController(){
		
	}
	/**
	 * The main method
	 * @param args
	 * Command-line arguments
	 */
	public void main(String[] args){
		
	}
}
