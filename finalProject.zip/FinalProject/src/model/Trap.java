package model;

/**
 * this class represents the Trap item
 * 
 * @author Team Barbs
 *
 */
public class Trap extends Item {

	/**
	 * trap
	 * 
	 * this is the constructor
	 * 
	 */
	public Trap() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * use
	 * 
	 * this lays a trap
	 * 
	 * @return boolean
	 * 
	 */
	public boolean use() {
		// TODO Auto-generated method stub
		return false;
	}

}
